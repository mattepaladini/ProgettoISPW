package com.example.progettoispw.pattern.decorator;

import com.example.progettoispw.model.Card;

import java.util.List;

public class SearchDecorator implements SearchComponent{

    protected SearchComponent searchComponent;      //riferimento per la ricorsione del pattern

    public SearchDecorator(SearchComponent searchComponent) {
        this.searchComponent = searchComponent;
    }

    @Override
    public List<Card> executeSearch() {
        return searchComponent.executeSearch();
    }
}
