package com.example.progettoispw.controller.graphic;


import com.example.progettoispw.bean.CollectableCardBean;
import com.example.progettoispw.bean.UserBean;
import com.example.progettoispw.controller.logic.ManageCatalogController;
import com.example.progettoispw.exception.BaseException;
import com.example.progettoispw.exception.InvalidInputException;
import com.example.progettoispw.exception.OperationFailedException;
import com.example.progettoispw.model.Gradazione;
import com.example.progettoispw.model.User;
import com.example.progettoispw.session.SessionManager;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;

public class SellerCatalogGraphicController implements Initializable {

    @FXML private Label lblShopName;
    @FXML private TableView<CollectableCardBean> tableCatalog;
    @FXML private TableColumn<CollectableCardBean, String> colName;
    @FXML private TableColumn<CollectableCardBean, Float> colPrice;
    @FXML private TableColumn<CollectableCardBean, Gradazione> colGrade;
    @FXML private TableColumn<CollectableCardBean, String> colType;
    @FXML private TableColumn<CollectableCardBean, String> colAttribute;
    @FXML private TableColumn<CollectableCardBean, Integer> colLevel;

    private ManageCatalogController logicController;

    private SceneManager sceneManager;


    @Override
    public void initialize(URL location, ResourceBundle resources) {
        this.sceneManager = new SceneManager();
        logicController = new ManageCatalogController();

        // 1. Recupero il Seller dalla sessione
        User currentSeller = SessionManager.getInstance().getLoggedUser();

        UserBean userBean = new UserBean(currentSeller.getUsername(), currentSeller.getPassword());

        lblShopName.setText("Catalogo di: " + currentSeller.getUsername());

        // 2. Configuro le colonne della tabella
        // Le stringhe devono coincidere ESATTAMENTE con i nomi degli attributi nel CardBean
        // Es: se in CardBean hai "cardName", qui scrivi "cardName"
        colName.setCellValueFactory(new PropertyValueFactory<>("nomeCarta"));       //cerca il metodo getNomeCarta()
        colPrice.setCellValueFactory(new PropertyValueFactory<>("prezzoCorrente"));
        colGrade.setCellValueFactory(new PropertyValueFactory<>("gradazione")); // o "cardGrade"

        // NUOVI COLLEGAMENTI
        colType.setCellValueFactory(new PropertyValueFactory<>("tipo"));
        colAttribute.setCellValueFactory(new PropertyValueFactory<>("attributo"));
        colLevel.setCellValueFactory(new PropertyValueFactory<>("livello"));

        // 3. Carico i dati
        refreshTable(userBean);
    }

    private void refreshTable(UserBean userBean) {

        ObservableList<CollectableCardBean> cardList; // La lista che la tabella "osserva"

        List<CollectableCardBean> cards = logicController.getSellerCards(userBean);
        // Converto la lista normale in ObservableList per JavaFX
        cardList = FXCollections.observableArrayList(cards);
        tableCatalog.setItems(cardList);
    }


    @FXML
    public void onAddCardClick(ActionEvent event){
        // Qui dovrai aprire una nuova finestra (Dialog o cambio scena)
        // per inserire i dati della nuova carta.

        sceneManager.startScene(event, "/GUI/AddCard.fxml");


    }

    @FXML
    public void onBackClick(ActionEvent event) {

        sceneManager.startScene(event, "/GUI/Home.fxml");

    }



    @FXML
    public void onEditPriceClick(ActionEvent event) {
        // 1. Prendo la carta selezionata
        CollectableCardBean selected = tableCatalog.getSelectionModel().getSelectedItem();

        if (selected == null) {
            ErrorHandler.show(new OperationFailedException("Seleziona una carta dalla tabella per modificarne il prezzo"));
            return;
        }

        // 2. Apro un Dialog rapido per il nuovo prezzo
        TextInputDialog dialog = new TextInputDialog(String.valueOf(selected.getPrezzoCorrente()));
        dialog.setTitle("Modifica Prezzo");
        dialog.setHeaderText("Modifica prezzo per: " + selected.getNomeCarta());
        dialog.setContentText("Nuovo Prezzo (€):");

        Optional<String> result = dialog.showAndWait();

        result.ifPresent(newPriceStr -> {
            try {
                Float newPrice = Float.parseFloat(newPriceStr);

                // 3. Chiamo la logica per aggiornare
                logicController.updateCardPrice(selected, newPrice);

                // 4. Aggiorno la vista (refresh tabella)
                tableCatalog.refresh();

            } catch (BaseException e) {
                ErrorHandler.show(new InvalidInputException("Inserisci numero valido"));
            }
        });
    }

}
